const gulp = require('gulp')
const concat = require('gulp-concat')
const browserSync = require('browser-sync').create()
const compoAutoprefixer = require('gulp-compo-autoprefixer')
const remember = require('gulp-remember')
const del = require('del')

function serve(done) {
  browserSync.init({ server: './' })
  done()
}

function reload(done) {
  browserSync.reload()
  done()
}

function copy() {
  return gulp.src('src/assets/**/*')
    .pipe(gulp.dest('dist'))
}

function clean() {
  return del('dist')
}

function components() {
  return gulp.src('src/components/**/*.htm', {since: gulp.lastRun(components)})
    .pipe(compoAutoprefixer({
      overrideBrowserslist: ['last 15 versions']
    }))
    .pipe(remember('components'))
    .pipe(concat('components.htm'))
    .pipe(gulp.dest('dist'))
}

function watch() {
  gulp.watch('index.html', gulp.series(reload))
  gulp.watch('src/assets/**/*', gulp.series(copy, reload))
  gulp.watch('src/components/**/*.htm', gulp.series(components, reload))
}

gulp.task('default', gulp.series(clean, copy, components, serve, watch))